# crud_nodejs_datatables
CRUD con NODE JS con datatables, sweet alert 2 y font awesome
